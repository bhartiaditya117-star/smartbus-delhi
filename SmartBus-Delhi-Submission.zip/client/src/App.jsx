
import { useState, useEffect } from "react";
import { io } from "socket.io-client";
import {
  BusFront,
  LayoutDashboard,
  MapPin,
  Route,
  Activity,
  Users,
  Bell,
  Search
} from "lucide-react";

import {
  MapContainer,
  TileLayer,
  CircleMarker,
  Popup
} from "react-leaflet";

import "leaflet/dist/leaflet.css";
import RoutingControl from "./RoutingControl";
import "./App.css";

const buses = [
  { id: "DL-01-1024", route: "Route 604", position: [28.6139, 77.2090], speed: 34 },
  { id: "DL-01-2088", route: "Route 764", position: [28.6280, 77.2180], speed: 22 },
  { id: "DL-01-3091", route: "Route 522", position: [28.6000, 77.1950], speed: 41 },
  { id: "DL-01-4112", route: "Route 425", position: [28.6410, 77.2300], speed: 18 },
  { id: "DL-01-5120", route: "Route 781", position: [28.6200, 77.1850], speed: 15 }
];

function App() {
  const [from, setFrom] = useState("Connaught Place");
  const [to, setTo] = useState("India Gate");
  const [journey, setJourney] = useState(false);
  const [routeInfo, setRouteInfo] = useState(null);
  const [fromPosition, setFromPosition] = useState(null);
const [toPosition, setToPosition] = useState(null);

const [liveBuses, setLiveBuses] = useState(buses);
const [lastUpdated, setLastUpdated] = useState(new Date());
useEffect(() => {
  const socket = io("http://localhost:5001");

  socket.on("connect", () => {
    console.log("Connected to SmartBus backend!");
  });

  socket.on("busUpdate", (updatedBuses) => {
    const formattedBuses = updatedBuses.map((bus) => ({
      ...bus,
      position: [bus.latitude, bus.longitude]
    }));

    setLiveBuses(formattedBuses);
    setLastUpdated(new Date());
  });

  return () => {
    socket.disconnect();
  };
}, []);

useEffect(() => {
  const timer = setInterval(() => {
    setLastUpdated(new Date());
    setLiveBuses((currentBuses) =>
      currentBuses.map((bus) => ({
        ...bus,
        position: [
          bus.position[0] + (Math.random() - 0.5) * 0.001,
          bus.position[1] + (Math.random() - 0.5) * 0.001
        ]
      }))
    );
  }, 3000);

  return () => clearInterval(timer);
}, []);


const handleJourneySubmit = async (e) => {
  e.preventDefault();
  setJourney(false);

  try {
    const findLocation = async (place) => {
      const response = await fetch(
        `https://nominatim.openstreetmap.org/search?format=json&q=${encodeURIComponent(place + ", Delhi, India")}&limit=1`
      );

      const data = await response.json();

      if (!data.length) {
        throw new Error(`Location not found: ${place}`);
      }

      return [
        Number(data[0].lat),
        Number(data[0].lon)
      ];
    };

    const start = await findLocation(from);
    const destination = await findLocation(to);

    setFromPosition(start);
    setToPosition(destination);
    setJourney(true);

  } catch (error) {
    alert(error.message);
  }
};


  return (
    <div className="app">

      <aside className="sidebar">
        <div className="brand">
          <BusFront size={30} />
          <h2>SmartBus</h2>
        </div>

        <p className="side-label">WORKSPACE</p>

        <div className="side-link active">
          <LayoutDashboard size={19} /> Overview
        </div>

        <div className="side-link">
          <MapPin size={19} /> Live Tracking
        </div>

        <div className="side-link">
          <Route size={19} /> Journey Planner
        </div>

        <div className="side-link">
          <Activity size={19} /> Traffic Intelligence
        </div>

        <div className="side-bottom">
          <div className="online-dot"></div>
          System Operational
          <p>Aditya Kumar · Administrator</p>
        </div>
      </aside>

      <main className="main">

        <header className="topbar">
          <div>
            <small>Workspace / Overview</small>
            <h1>Dashboard</h1>
          </div>

          <div className="top-actions">
            <div className="search">
              <Search size={17} />
              <input placeholder="Search buses..." />
            </div>
            <Bell size={21} />
            <div className="avatar">AK</div>
          </div>
        </header>

        <section className="content">

          <div className="welcome">
            <div>
              <span>SMART MOBILITY CONTROL CENTER</span>
              <h2>Welcome to SmartBus 👋</h2>
              <p>Monitor Delhi's public transport network in one place.</p>
            </div>
           
<div className="live-badge">
  <span></span>
  LIVE GPS · Updated: {lastUpdated.toLocaleTimeString()}
</div>

          </div>

          <div className="stats">

            <div className="stat-card">
              <BusFront />
              <p>Total Buses</p>
              <h2>248</h2>
              <small>Demo fleet capacity</small>
            </div>

            <div className="stat-card">
              <Activity />
              <p>Active Buses</p>
              <h2>186</h2>
              <small>Simulated active fleet</small>
            </div>

            <div className="stat-card">
              <Users />
              <p>Passengers</p>
              <h2>12.8K</h2>
              <small>Sample daily estimate</small>
            </div>

            <div className="stat-card">
              <Route />
              <p>Average Speed</p>
              <h2>28 km/h</h2>
              <small>Sample speed estimate</small>
            </div>

          </div>

          <div className="section-title">
            <div>
              <h2>Live Network Overview</h2>
              <p>Explore bus locations around New Delhi.</p>
            </div>
            <span>DELHI, INDIA</span>
          </div>

          <div className="dashboard-grid">

            <div className="map-card">
              <div className="card-heading">
                <h3>Delhi Bus Network</h3>
                <span>DEMO DATA</span>
              </div>

              <MapContainer
                center={[28.6139, 77.2090]}
                zoom={12}
                scrollWheelZoom={true}
                className="map"
              >
                <TileLayer
                  attribution='&copy; OpenStreetMap contributors'
                  url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
                />

                {liveBuses.map((bus, index) => (
                  <CircleMarker
                    key={bus.id}
                    center={bus.position}
                    radius={9}
                    pathOptions={{
                      color: "white",
                      weight: 3,
                      fillColor: index % 2 === 0 ? "#16a36a" : "#f59e0b",
                      fillOpacity: 1
                    }}
                  >
                    <Popup>
                      <strong>{bus.id}</strong>
                      <br />
                      {bus.route}
                      <br />
                      Speed: {bus.speed} km/h
                      <br />
                      GPS: Simulated
                    </Popup>
                  </CircleMarker>
                ))}


{journey && fromPosition && toPosition && (
  <RoutingControl
    fromPosition={fromPosition}
    toPosition={toPosition}
    onRouteInfo={setRouteInfo}
  />
)}
              </MapContainer>

              <div className="map-legend">
                <span>🟢 On time</span>
                <span>🟠 Delayed</span>
                <span>Click a bus marker for details</span>
              </div>
            </div>

            <div className="right-panel">

              <div className="journey-card">
                <h3>Plan Your Journey</h3>
                <p>Find your next bus journey.</p>

                <form onSubmit={handleJourneySubmit}>
                  <label>FROM</label>
                  <input
                    value={from}
                    onChange={(e) => {
                      setFrom(e.target.value);
                      setJourney(false);
                    }}
                    required
                  />

                  <label>TO</label>
                  <input
                    value={to}
                    onChange={(e) => {
                      setTo(e.target.value);
                      setJourney(false);
                    }}
                    required
                  />

                  <button type="submit">Find Bus Routes →</button>
                </form>

                {journey && (
                  <div className="journey-result">
                    <strong>Journey request received!</strong>
                    <p>{from} → {to}</p>
                   <small>
  {routeInfo
    ? `Estimated journey: ${routeInfo.distance} km · Approx. ${routeInfo.duration} minutes`
    : "Calculating route..."}
</small>
                  </div>
                )}
              </div>

              <div className="traffic-card">
                <h3>Traffic Conditions</h3>
                <p>Sample congestion indicators</p>

                <div className="traffic-row">
                  <span className="green"></span>
                  <div>Central Delhi<small>Low congestion</small></div>
                  <strong>32%</strong>
                </div>

                <div className="traffic-row">
                  <span className="yellow"></span>
                  <div>South Delhi<small>Moderate</small></div>
                  <strong>58%</strong>
                </div>

                <div className="traffic-row">
                  <span className="red"></span>
                  <div>North Delhi<small>Heavy congestion</small></div>
                  <strong>86%</strong>
                </div>
              </div>

            </div>
          </div>

          <div className="fleet-title">
            <h2>Bus Fleet Monitoring</h2>
            <span>5 DEMO RECORDS</span>
          </div>

          <div className="table-card">
            <table>
              <thead>
                <tr>
                  <th>BUS ID</th>
                  <th>ROUTE</th>
                  <th>SPEED</th>
                  <th>GPS STATUS</th>
                </tr>
              </thead>

              <tbody>
                {liveBuses.map((bus) => (
                  <tr key={bus.id}>
                    <td><strong>{bus.id}</strong></td>
                    <td>{bus.route}</td>
                    <td>{bus.speed} km/h</td>
                    <td className="connected">● Connected (simulation)</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          <footer>
            SmartBus Delhi © 2026 | Hackathon Prototype
            <span>GPS data is simulated in this version.</span>
          </footer>

        </section>
      </main>
    </div>
  );
}

export default App;
