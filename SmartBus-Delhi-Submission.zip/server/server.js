
const express = require("express");
const http = require("http");
const cors = require("cors");
const dotenv = require("dotenv");
const { Server } = require("socket.io");

dotenv.config();

const app = express();
const server = http.createServer(app);

const io = new Server(server, {
  cors: {
    origin: "http://localhost:5174",
    methods: ["GET", "POST"]
  }
});

app.use(cors());
app.use(express.json());

// Server status API
app.get("/", (req, res) => {
  res.json({
    message: "SmartBus Delhi Backend is running!",
    status: "Online",
    mode: "Hackathon Prototype"
  });
});

// Demo bus records
let buses = [
  {
    id: "DL-01-1024",
    route: "Route 604",
    latitude: 28.6139,
    longitude: 77.2090,
    speed: 34
  },
  {
    id: "DL-01-2088",
    route: "Route 764",
    latitude: 28.6280,
    longitude: 77.2180,
    speed: 22
  },
  {
    id: "DL-01-3091",
    route: "Route 522",
    latitude: 28.6000,
    longitude: 77.1950,
    speed: 41
  },
  {
    id: "DL-01-4112",
    route: "Route 425",
    latitude: 28.6410,
    longitude: 77.2300,
    speed: 18
  },
  {
    id: "DL-01-5120",
    route: "Route 781",
    latitude: 28.6200,
    longitude: 77.1850,
    speed: 15
  }
];

// Get all buses
app.get("/api/buses", (req, res) => {
  res.json({
    success: true,
    count: buses.length,
    data: buses
  });
});

// Socket.IO connection
io.on("connection", (socket) => {
  console.log("A passenger connected:", socket.id);

  socket.emit("busUpdate", buses);

  socket.on("disconnect", () => {
    console.log("Passenger disconnected:", socket.id);
  });
});

// Simulated GPS updates every 3 seconds
setInterval(() => {
  buses = buses.map((bus) => ({
    ...bus,
    latitude: bus.latitude + (Math.random() - 0.5) * 0.001,
    longitude: bus.longitude + (Math.random() - 0.5) * 0.001
  }));

  io.emit("busUpdate", buses);

  console.log("Demo GPS locations updated");
}, 3000);

// Start server
const PORT = process.env.PORT || 5001;

server.listen(PORT, () => {
  console.log(`SmartBus backend running at http://localhost:${PORT}`);
});
